package com.esoft.web;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class ESoftFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "esoft_notifications";


    @Override
    public void onNewToken(String token) {
        getSharedPreferences("esoft_fcm", MODE_PRIVATE).edit().putString("fcm_token", token).apply();
        super.onNewToken(token);
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        String title = message.getNotification() != null && message.getNotification().getTitle() != null
                ? message.getNotification().getTitle() : message.getData().get("title");
        String body = message.getNotification() != null && message.getNotification().getBody() != null
                ? message.getNotification().getBody() : message.getData().get("body");

        if (title == null || title.isEmpty()) title = "ESoft";
        if (body == null) body = "You have a new notification.";

        int number = 0;
        try {
            number = Integer.parseInt(message.getData().getOrDefault("badge", "0"));
        } catch (Exception ignored) { }

        showNotification(this, title, body, number);
    }

    public static void showLocalNotification(Context context, String title, String body) {
        showNotification(context, title, body, 0);
    }

    private static void showNotification(Context context, String title, String body, int number) {
        createChannel(context);
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_esoft)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        if (number > 0) builder.setNumber(number);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify((int) System.currentTimeMillis(), builder.build());
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "ESoft Notifications", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Notifications from ESoft");
            manager.createNotificationChannel(channel);
        }
    }
}
