package com.esoft.web;

import android.webkit.JavascriptInterface;

public class NativeNotificationBridge {
    private final MainActivity activity;

    public NativeNotificationBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public void showNotification(String title, String body) {
        activity.runOnUiThread(() -> activity.showNativeNotification(title, body));
    }

    @JavascriptInterface
    public String getFcmToken() {
        return activity.getFcmToken();
    }
}
