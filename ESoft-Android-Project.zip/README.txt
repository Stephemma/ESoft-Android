ESoft Android wrapper
======================

This project loads the LIVE ESoft website:
https://esoftweb.netlify.app/

It does NOT bundle a second copy of the website.

Build:
1. Put this project in a GitHub repository.
2. Open Actions -> Build ESoft APK -> Run workflow.
3. Download the ESoft-debug-apk artifact.
4. Extract the APK and install it on Android.

Important:
- This is a DEBUG APK for testing, not a Play Store release.
- Before public distribution, review security of client-side secrets in the website
  (for example config.js) and use a proper signing key/release build.
