ESoft Android wrapper
======================

This project loads the LIVE ESoft website:
https://esoftweb.netlify.app/

It does NOT bundle a second copy of the website.

Build:
1. Put this project in a GitHub repository.
2. Open Actions -> Build ESoft APK -> Run workflow.
3. Download the ESoft-debug-apk artifact.
4. Extract the APK and install it on Android.

Important:
- This is a DEBUG APK for testing, not a Play Store release.
- Before public distribution, review security of client-side secrets in the website
  (for example config.js) and use a proper signing key/release build.

Updated against ESoft v5 notifications website.
The Android WebView bridges the website's Firestore notification listener to native Android notifications.
Important: the current website notification implementation writes Firestore notification documents and calls the Web Notification API; it is not a server-side FCM sender. This update makes those website-generated local notifications display as native Android notifications while the WebView process is active. Reliable delivery when the app process is killed still requires a backend/Cloud Function (or another trusted server) to send FCM messages to device tokens.

FCM BACKGROUND PUSH UPDATE
--------------------------
This version uses real Firebase Cloud Messaging for Android background delivery.
The APK obtains a native FCM token and passes it to the signed-in ESoft Firebase session. The companion Firebase Functions in the ESoft website package store the token and send FCM whenever a Firestore notification document is created.

The Android side alone cannot securely send targeted FCM messages; deploy the companion functions before expecting server-side notifications while the app is closed.
