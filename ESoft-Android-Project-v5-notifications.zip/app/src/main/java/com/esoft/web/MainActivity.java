package com.esoft.web;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestNotificationPermission();
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token ->
                getPreferences(MODE_PRIVATE).edit().putString("fcm_token", token).apply());
        getWindow().setStatusBarColor(Color.rgb(23, 21, 18));
        getWindow().setNavigationBarColor(Color.rgb(23, 21, 18));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(23, 21, 18));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new NativeNotificationBridge(this), "ESoftNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                String js = "(function(){" +
                        "window.fireLocalNotification=function(title,body){try{if(window.ESoftNative){window.ESoftNative.showNotification(String(title||\"ESoft\"),String(body||\"You have a new notification.\"));}}catch(e){console.error(e);}};" +
                        "window.requestNotifyPermission=function(){};" +
                        "var p=location.pathname||'';" +
                        "if(p.indexOf('history.html')===-1 && p.indexOf('admin.html')===-1 && window.firebase && window.listenUserNotifications && window.auth && window.db && !window.__esoftNativeListener){" +
                        "window.__esoftNativeListener=true; firebase.auth().onAuthStateChanged(function(u){if(u){window.listenUserNotifications(window.db,u.uid,'navNotifBadge');}});" +
                        "}" +
                        "})();";
                view.evaluateJavascript(js, null);
            }
        });

        webView.loadUrl("https://esoftweb.netlify.app/");
    }

    public void showNativeNotification(String title, String body) {
        ESoftFirebaseMessagingService.showLocalNotification(this, title, body);
    }

    private void requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
}
